let nav=document.getElementById('nav');
let enlaces=document.getElementById('enlaces');
let abrir=document.getElementById('open');
let botones=document.getElementsByClassName('btn-header');
let cerrado=true;

window.addEventListener('scroll', function(){
    menus();
});
window.addEventListener('load', function(){
    
});
function menus(){
    let Desplazamiento_actual=window.pageYOffset;

    if(Desplazamiento_actual <= 300){
        nav.classList.remove('nav2');
        nav.className=('nav1');
        nav.style.transition='1s';
        enlaces.style.top='80px';
    }else{
        nav.classList.remove('nav1');
        nav.className=('nav2');
        nav.style.transition='1s';
        enlaces.style.top='100px';
    }
}

function apertura(){
    if(cerrado){
        enlaces.style.width = '70vw';
        cerrado=false;
    }else{
        enlaces.style.width = '0%';
        enlaces.style.overflow = 'hidden';
        cerrado=true;
    }
}
window.addEventListener('resize', function(){
    if(screen.width>=700){
        cerrado=true;
        enlaces.style.removeProperty('overflow');
        enlaces.style.removeProperty('width');
        
    }
});
window.addEventListener('click', function(e){
    console.log(e.target);
    if(cerrado==false){
        let span = document.querySelector('span');
        if(e.target !== span && e.target !== abrir){
            enlaces.style.width = '0%';
            enlaces.style.overflow = 'hidden';
            cerrado=true;
        }
    }
});

abrir.addEventListener('click', function(){
    apertura();
});