$(function(){
    $('.filter').click(function(){
        $(this).addClass('active').siblings().removeClass('active');
        
        let valor= $(this).attr('data-nombre');
        if(valor === 'todos'){
            $('.cwork').show('1000');
        }else{
            $('.cwork').not('.'+ valor).hide('1000');
            $('.cwork').filter('.'+valor).show('1000');
        }
    });

    let servicios = $('#servicios').offset().top;
    let somos = $('#somos').offset().top;
    let  trabajos = $('#trabajos').offset().top;
    let contacto = $('#contacto').offset().top;
    
    window.addEventListener('resize', function(){
        let somos = $('#somos').offset().top;
        let servicios = $('#servicios').offset().top;
        let trabajos = $('#trabajos').offset().top;
        let contacto = $('#contacto').offset().top;
    });
    
    $('#enlace-inicio').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 600);
    });
    
    $('#enlace-servicios').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: servicios-100
        }, 600);
    });
    
    $('#enlace-somos').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: somos-100
        }, 600);
    });
    
    $('#enlace-trabajo').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: trabajos-100
        }, 600);
    });

    $('#enlace-contacto').on('click', function(e){
        e.preventDefault();
        $('html, body').animate({
            scrollTop: contacto-100
        }, 600);
    });

});